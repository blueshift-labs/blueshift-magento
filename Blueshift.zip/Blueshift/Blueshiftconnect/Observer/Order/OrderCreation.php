<?php 
/**
 * Blueshift Blueshiftconnect order creation Observer
 * @category  Blueshift
 * @package   Blueshift_Blueshiftconnect
 * @author    Blueshift
 * @copyright Copyright (c) Blueshift(https://blueshift.com/)
 */
namespace Blueshift\Blueshiftconnect\Observer\Order;
use Magento\Framework\Event\ObserverInterface;
use Psr\Log\LoggerInterface as Logger;
use Blueshift\Blueshiftconnect\Helper\BlueshiftConfig as BlueshiftConfig;
use Magento\Customer\Api\AddressRepositoryInterface;

class OrderCreation implements ObserverInterface {
    protected $logger;
    protected $orderRepository;
    private $addressRepository;
    /**
     * @param ScopeConfigInterface $scopeConfig,
     * @param BlueshiftConfig $blueshiftConfig
     * @param OrderRepository $orderRepository
     */
    public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,\Magento\Sales\Model\OrderRepository $orderRepository,BlueshiftConfig $blueshiftConfig, AddressRepositoryInterface $addressRepository) {
        $this->_scopeConfig = $scopeConfig;
        $this->orderRepository = $orderRepository;
        $this->blueshiftConfig = $blueshiftConfig;
        $this->addressRepository = $addressRepository;
    }
    /**
     * get data after order creation event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer){ 
        try{
            $customer_data =  array();
            $eventkey = $this->_scopeConfig->getValue('blueshiftconnect/Step1/eventapikey');
            $password = '';
            $data = array();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
            $baseUrl = $storeManager->getStore()->getBaseUrl();
            $order = $observer->getOrder();
            $order_details = $order->getData();
            $orders = $order->getAllItems();
            $i=0;
            $orderRepository = $this->orderRepository->get($order_details['id']);
            $items = $observer->getQuote()->getAllItems();

            foreach ($orders as $orderItem) {
                $orderItems = $orderItem->getData();
                $data['customer_id']= $order_details['customer_id'];
                $data['email']= $order_details['customer_email'];
                $data['order_id']= $order_details['id'];
                $data['event']= "purchase";
                $chileId = $orderItems['product_id'];
                $parenProduct = $objectManager->create('Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable')->getParentIdsByChild($chileId);
                $parenProduct = $objectManager->create('Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable')->getParentIdsByChild($chileId);
                if ( !in_array($orderItems['product_type'], array('configurable', 'bundle'))) {
                    if(isset($parenProduct[0])){
                        $productRepository = $objectManager->get('\Magento\Catalog\Model\ProductRepository');
                        $product = $productRepository->getById($parenProduct[0]);
                        $data['products'][$i]['parent_sku'] = $product->getSKU();
                    } else {
                        $data['products'][$i]['parent_sku']=$orderItems['sku'];
                    }
                    $data['products'][$i]['sku']=$orderItems['sku'];
                    $data['products'][$i]['price']=$orderItems['price'];
                    $data['products'][$i]['qty']=$orderItems['qty_ordered'];
                }
                $data['revenue']=$orderRepository->getGrandTotal();

                $data['ip']=$order_details['remote_ip'];
                $data['products__qty']=$order_details['total_qty_ordered'];
                $data['products__discounted_price']=$orderItems['discount_amount'];
                $data['storeUrl']=$baseUrl;
                $data['timestamp'] = date("Y/m/d H:s");
                $addressData = $order_details['addresses'];
                foreach ($addressData as $address) {
                    $record = $address->getData();
                    if ( in_array('shipping', $record) ) {
                        $data['ship_address__lastname']=$record['lastname'];
                        $data['ship_address__postcode']=$record['postcode'];
                        $data['ship_address__city']=$record['city'];
                        $data['ship_address__customer_address_id']=$record['customer_address_id'];
                        $data['ship_address__entity_id']=$record['entity_id'];
                        $data['ship_address__parent_id']=$record['parent_id'];
                        $data['ship_address__firstname']=$record['firstname'];
                        $data['ship_address__id']=$record['id'];
                        $data['ship_address__street']=$record['street'];
                        $data['ship_address__telephone']=$record['telephone'];
                        $data['ship_address__region_id']=$record['region_id'];
                        $data['ship_address__country_id']=$record['country_id'];
                        $data['ship_address__email']=$record['email'];
                        $data['ship_address__region']=$record['region'];
                        $data['ship_address__address_type']=$record['address_type'];
                    }
                    if ( in_array('billing', $record) ) {
                        $data['bill_address__city']=$record['city'];
                        $data['bill_address__region']=$record['region'];
                        $data['bill_address__street']=$record['street'];
                        $data['bill_address__telephone']=$record['telephone'];
                        $data['bill_address__parent_id']=$record['parent_id'];
                        $data['bill_address__customer_address_id']=$record['customer_address_id'];
                        $data['bill_address__region_id']=$record['region_id'];
                        $data['bill_address__postcode']=$record['postcode'];
                        $data['bill_address__entity_id']=$record['entity_id'];
                        $data['bill_address__email']=$record['email'];
                        $data['bill_address__id']=$record['id'];
                        $data['bill_address__country_id']=$record['country_id'];
                        $data['bill_address__firstname']=$record['firstname'];
                        $data['bill_address__address_type']=$record['address_type'];
                        $data['bill_address__lastname']=$record['lastname'];
                    }
                } 
                $i++;
            } 
            $websiteId =$this->blueshiftConfig->getWebsiteId();
            $data['website_id']=$websiteId;
            $json_data = json_encode($data);
            $path = "event";
            $method = "POST";
            $result = $this->blueshiftConfig->curlFunc($json_data,$path,$method,$password,$eventkey);
            if($result['status']== 200){
                $this->blueshiftConfig->loggerWrite("Order creation: status = ok ",'observer');
            }else{
                $result = json_encode($result);
                $this->blueshiftConfig->loggerWrite("Order creation: ".$result,'observer');
            } 
        }catch (\Exception $e) {
            $this->blueshiftConfig->loggerWrite($e->getMessage(),'observer');
        }
    }
}
