<?php 
/**
 * Blueshift Blueshiftconnect Customer creation
 * @category  Blueshift
 * @package   Blueshift_Blueshiftconnect
 * @author    Blueshift
 * @copyright Copyright (c) Blueshift(https://blueshift.com/)
 */
namespace Blueshift\Blueshiftconnect\Observer\Customer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer as EventObserver;
use Blueshift\Blueshiftconnect\Helper\BlueshiftConfig as BlueshiftConfig;

class SignUp implements ObserverInterface {

    protected $_customerRepositoryInterface;

    /**
     * @param ScopeConfigInterface $scopeConfig,
     * @param \Magento\Framework\UrlInterface $url
     * @param BlueshiftConfig $blueshiftConfig
     */
    public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,BlueshiftConfig $blueshiftConfig, \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface) {
        $this->_scopeConfig = $scopeConfig;
        $this->blueshiftConfig = $blueshiftConfig;
        $this->_customerRepository = $customerRepositoryInterface;
    }
    /**
     * get customer data after customer added from frontend event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer){
        try{
             $eventkey = $this->_scopeConfig->getValue('blueshiftconnect/Step1/eventapikey');
            $password = '';
            $data =  array();
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $storeManager = $objectManager->get('\Magento\Store\Model\StoreManagerInterface');
            $baseUrl = $storeManager->getStore()->getBaseUrl();
            $customer = $observer->getEvent()->getCustomer();
            $customerId = $customer->getId();
            $customerData = $this->_customerRepository->getById($customerId);
            $customerFirstName = $customerData->getFirstName();
            $customerLastName = $customerData->getLastName();
            $customerEmail = $customerData->getEmail();

            $data['storeUrl']=$baseUrl;
            $data['customer_id'] = $customerId;
            $data['email'] = $customerEmail;
            $data['firstname'] = $customerFirstName;
            $data['lastname']  = $customerLastName;
            $data['event'] = "signed_up";
            $data['timestamp'] = date('Y/m/d H:m:s');
            $websiteId =$this->blueshiftConfig->getWebsiteId();
            $data['website_id']=$websiteId;
            $json_data = json_encode($data);
            $path = "event";
            $method = "POST";
            $result = $this->blueshiftConfig->curlFunc($json_data,$path,$method,$password,$eventkey);
            if($result['status']== 200){
                $this->blueshiftConfig->loggerWrite("Customer SignUp: status = ok",'observer');
            }else{
                $result = json_encode($result);
                $this->blueshiftConfig->loggerWrite("Customer SignUp: ".$result,'observer');
            }  
        }catch (\Exception $e) {
            $this->blueshiftConfig->loggerWrite($e->getMessage(),'observer');
        }
    }
}
